# for debugger console
INSERT INTO tiki_preferences(name,value) VALUES ('feature_debugger_console','n');

