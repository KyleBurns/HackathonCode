<?php

// This section was moved to admin home and is now accessible by clicking an icon
header("Location: tiki-admin.php?page=score");

?>
