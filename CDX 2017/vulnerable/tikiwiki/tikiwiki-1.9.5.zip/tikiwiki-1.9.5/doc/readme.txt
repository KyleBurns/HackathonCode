The .pdf and .doc versions of the docs have been removed from the official
Tiki sources distribution since they were too big. You can download them
from a separate package from SourceForge.

Our SourceForge project URL is https://sourceforge.net/projects/tikiwiki.  We
also have a TikiWiki site for the documentation, which is currently a work
in progress available for reference at http://doc.tikiwiki.org

It is highly recommended to read the docs to understand all the Tiki features
and how to configure them.

Thanks!

TikiWiki Community
