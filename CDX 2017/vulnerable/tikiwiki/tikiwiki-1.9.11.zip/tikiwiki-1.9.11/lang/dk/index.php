<?php

// $Header: /cvsroot/tikiwiki/tiki/lang/dk/index.php,v 1.1.2.1 2005/02/15 19:29:50 jmjuzan Exp $

// This redirects to the sites root to prevent directory browsing

header ("location: ../../tiki-index.php");
die;

?>
