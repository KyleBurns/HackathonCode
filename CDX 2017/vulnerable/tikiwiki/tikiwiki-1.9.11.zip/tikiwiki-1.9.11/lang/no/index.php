<?php

// $Header: /cvsroot/tikiwiki/tiki/lang/no/index.php,v 1.3.2.2 2007/03/02 12:13:24 luciash Exp $

// Copyright (c) 2002-2007, Luis Argerich, Garland Foster, Eduardo Polidor, et. al.
// All Rights Reserved. See copyright.txt for details and a complete list of authors.
// Licensed under the GNU LESSER GENERAL PUBLIC LICENSE. See license.txt for details.

// This redirects to the sites root to prevent directory browsing

header ("location: ../../tiki-index.php");
die;

?>
