<?php

// $Header: /cvsroot/tikiwiki/tiki/lang/hr/index.php,v 1.1.2.1 2005/02/15 19:30:01 jmjuzan Exp $

// This redirects to the sites root to prevent directory browsing

header ("location: ../../tiki-index.php");
die;

?>
