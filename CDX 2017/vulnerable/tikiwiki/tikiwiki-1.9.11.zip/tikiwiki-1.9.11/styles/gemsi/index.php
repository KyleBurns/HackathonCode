<?php

// $Header: /cvsroot/tikiwiki/tiki/styles/gemsi/index.php,v 1.1.2.1 2005/02/15 19:17:02 jmjuzan Exp $

// This redirects to the sites root to prevent directory browsing

header ("location: ../../tiki-index.php");
die;

?>
