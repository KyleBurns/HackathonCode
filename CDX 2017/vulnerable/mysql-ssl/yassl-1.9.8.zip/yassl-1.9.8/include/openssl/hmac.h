/* hmac.h  for openvpn */
