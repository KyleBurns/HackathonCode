/* des.h  for openssl */
