/* rand.h for openSSL */

