/* objects.h  for openvpn */
