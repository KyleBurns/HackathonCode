/* evp.h for openSSL */

#ifndef SSLEAY_NUMBER_DEFINED
#define SSLEAY_NUMBER_DEFINED

/* for OpenVPN */
#define SSLEAY_VERSION_NUMBER 0x0090700f


#endif /* SSLEAY_NUMBER_DEFINED */
